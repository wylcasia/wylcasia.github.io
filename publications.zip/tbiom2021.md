---
title: "Flexible Iris Matching Based on Spatial Feature Reconstruction"
authors:
- Yan Zihui
- He Lingxiao
- Wang Yunlong
- Sun, Zhenan
- Tan, Tieniu




date: "2021-08-30"

publication: "IEEE TBIOM"

links:
    cite: bibs/tbiom2021.bib
    pdf: https://doi.org/10.1109/TBIOM.2021.3108559
    # dataset: http://www.cripacsir.cn/dataset/casia-iris-degradation/
    # code: https://arxiv.org/pdf/2109.00162.pdf
    # pdf: https://github.com/hadisinaee/avicenna
    
    # slides: https://github.com/hadisinaee/avicenna
    # video: https://github.com/hadisinaee/avicenna

---

