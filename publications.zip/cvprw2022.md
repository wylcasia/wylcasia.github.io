---
title: "FedIris: Towards More Accurate and Privacy-preserving Iris Recognition via Federated Template Communication"
authors:
- LuoZhengquan
- Wang Yunlong*
- Wang Zilei
- Sun Zhenan
- Tan Tieniu

date: "2022-04-06"

publication: "CVPRW"

links:
    cite: bibs/cvprw2022.bib
    pdf: https://openaccess.thecvf.com/content/CVPR2022W/FedVision/html/Luo_FedIris_Towards_More_Accurate_and_Privacy-Preserving_Iris_Recognition_via_Federated_CVPRW_2022_paper.html
    # pdf: https://ieeexplore.ieee.org/document/9557317
    # code: https://github.com/reborn20200813/uncertainty
    slides: ./papers/CVPRW2022_FedIris.pptx
    # video: https://github.com/hadisinaee/avicenna

---