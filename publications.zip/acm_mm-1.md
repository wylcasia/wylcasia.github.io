---
title: "Sensing Micro-Motion Human Patterns using Multimodal mmRadar and Video Signal for Affective and Psychological Intelligence"
authors:
- Ru Yiwei
- Li Peipei
- Sun Muyi
- Wang Yunlong
- Zhang Kunbo
- Li Qi
- He Zhaofeng
- Sun Zhenan

date: "2023-10-27"

publication: "ACM MM 2023"

links:
    cite: bibs/mm2023.bib
    pdf: https://dl.acm.org/doi/abs/10.1145/3581783.3611754
    # pdf: https://ieeexplore.ieee.org/document/9557317
    # code: https://github.com/reborn20200813/Contextual-Measures
    # slides: ./papers/CVPRW2022_FedIris.pptx
    # video: https://github.com/hadisinaee/avicenna

---