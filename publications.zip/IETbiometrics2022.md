---
title: "Combining 2D texture and 3D geometry features for Reliable iris presentation attack detection using light field focal stack"
authors:
- Zhengquan Luo
- Wang Yunlong*
- Nianfeng Liu
- Zilei Wang

date: "2022-08-27"

publication: "IET Biometrics"

links:
    cite: bibs/IETbiometrics2022.bib
    pdf: https://ietresearch.onlinelibrary.wiley.com/doi/full/10.1049/bme2.12092
    # pdf: https://ieeexplore.ieee.org/document/9557317
    # code: https://github.com/RenMin1991/Perturbation-Inactivate
    # slides: ./papers/CVPRW2022_FedIris.pptx
    # video: https://github.com/hadisinaee/avicenna

---