---
title: "ScleraSegNet: An attention assisted U-net model for accurate sclera segmentation"
authors:
- Wang Caiyong
- Wang Yunlong
- Liu Yunfan
- He Zhaofeng
- He Ran
- Sun, Zhenan


date: "2019-12-27"

publication: "IEEE TBIOM"

links:
    cite: bibs/tbiom2019.bib
    pdf: https://doi.org/10.1109/TBIOM.2019.2962190
    code: https://github.com/xiamenwcy/IrisSegBenchmark
    # pdf: https://github.com/hadisinaee/avicenna
    
    # slides: https://github.com/hadisinaee/avicenna
    # video: https://github.com/hadisinaee/avicenna

---

