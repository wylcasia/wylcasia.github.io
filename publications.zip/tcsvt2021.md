---
title: "Cross-spectral Iris Recognition by Learning Device-specific Band"
authors:
- Wei Jianze
- Wang Yunlong
- Li Yi
- He Ran
- Sun Zhenan

date: "2021-10-04"

publication: "IEEE TCSVT"

links:
    cite: bibs/tcsvt2021.bib
    # doi: https://doi.org/10.1109/TCSVT.2021.3117291
    pdf: https://doi.org/10.1109/TCSVT.2021.3117291
    code:  https://github.com/reborn20200813/CSINv2
    # slides: https://github.com/hadisinaee/avicenna
    # video: https://github.com/hadisinaee/avicenna

---


[See the wiki page for tutorial!](https://github.com/hadisinaee/avicenna/wiki)