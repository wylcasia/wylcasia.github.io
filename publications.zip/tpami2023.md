---
title: "Multiscale Dynamic Graph Representation for Biometric Recognition with Occlusions"
authors:
- Ren Min
- Wang Yunlong
- Zhu Yuhao
- Zhang Kunbo
- Sun Zhenan

date: "2023-07-20"

publication: "IEEE T-PAMI"

links:
    cite: bibs/tpami2023.bib
    code: https://github.com/RenMin1991/Dyamic-Graph-Representation
    pdf: https://ieeexplore.ieee.org/document/10193782
    # pdf: https://ieeexplore.ieee.org/document/9557317
    
    # slides: ./papers/CVPRW2022_FedIris.pptx
    # video: https://github.com/hadisinaee/avicenna

---