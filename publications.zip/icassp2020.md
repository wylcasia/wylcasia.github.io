---
title: "A lightweight multi-label segmentation network for mobile iris biometrics"
authors:
- Wang Caiyong
- Wang Yunlong
- Xu Boqiang
- He Yong
- Dong, Zhiwei
- Sun, Zhenan


date: "2020-05-08"

publication: "ICASSP"

links:
    cite: bibs/icassp2020.bib
    pdf: https://doi.org/10.1109/ICASSP40776.2020.9054353
    # code: https://github.com/Debatrix/DFSNet
    # pdf: https://github.com/hadisinaee/avicenna
    
    # slides: https://github.com/hadisinaee/avicenna
    # video: https://github.com/hadisinaee/avicenna

---

